package com.lab02.AluguelCarros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AluguelCarrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
